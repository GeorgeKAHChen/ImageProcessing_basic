﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;


namespace Text
{
    class save
    {
        public void op(PictureBox p)
        {
            p.SizeMode = PictureBoxSizeMode.Zoom;
            SaveFileDialog ofdlg = new SaveFileDialog();
            ofdlg.Filter = "tif File(*.tif)|*.tif|jpg File(*.jpg)|*.jpg";
            if (ofdlg.ShowDialog() == DialogResult.OK)
            {
                string folderP = ofdlg.FileName;
                Image img = p.Image;
                img.Save(folderP);
            }
        }
    }
}
