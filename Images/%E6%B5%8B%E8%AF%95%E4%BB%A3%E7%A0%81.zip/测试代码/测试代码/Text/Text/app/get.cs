﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;

namespace Text
{
    class get
    {
        public int[,] getpicture(PictureBox p)
        {
            Image im = p.Image;
            Color c = new Color();
            Bitmap box1 = new Bitmap(im);
            int x, y;
            x = p.Image.Width;
            y = p.Image.Height;
            int[,] k = new int[x, y];
            for (int i = 0; i < x; i++)
            {
                for (int j = 0; j < y; j++)
                {
                    c = box1.GetPixel(i, j);
                    int c0 = (int)(c.G);
                    k[i, j] = c0;
                }
            }
            return k;
        }
    }
}
