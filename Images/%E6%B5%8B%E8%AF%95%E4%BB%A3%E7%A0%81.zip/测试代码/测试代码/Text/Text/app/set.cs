﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;

namespace Text
{
    class set
    {
        public void setpicture(PictureBox p1, ref PictureBox p2, int[,] k)
        {
            p2.SizeMode = PictureBoxSizeMode.Zoom;
            Image i1 = p1.Image;
            Bitmap box = new Bitmap(i1);
            Color c = new Color();
            int x, y;
            x = p1.Image.Width;
            y = p1.Image.Height;
            for (int i = 0; i < x; i++)
            {
                for (int j = 0; j < y; j++)
                {
                    if (k[i, j] > 0)
                    {
                        Color c1 = Color.FromArgb(0,0,0);
                        box.SetPixel(i, j, c1);
                    }
                    else 
                    {
                      
                    }
                }
            }
            p2.Refresh();
            p2.Image = box;
        }
    }
}
