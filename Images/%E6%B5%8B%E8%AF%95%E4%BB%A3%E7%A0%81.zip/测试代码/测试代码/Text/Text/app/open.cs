﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;

namespace Text
{
    class open
    {
        public void op(PictureBox p)
        {
            p.SizeMode = PictureBoxSizeMode.Zoom;
            OpenFileDialog ofdlg = new OpenFileDialog();
            ofdlg.Filter = "tif File(*.tif)|*.tif|jpg File(*.jpg)|*.jpg";
            if (ofdlg.ShowDialog() == DialogResult.OK)
            {
                Bitmap image = new Bitmap(ofdlg.FileName);
                p.Image = image;
            }
        }
    }
}
