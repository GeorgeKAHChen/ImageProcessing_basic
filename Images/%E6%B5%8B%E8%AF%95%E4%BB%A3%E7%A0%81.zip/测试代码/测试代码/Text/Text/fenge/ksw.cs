﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;

namespace Text
{
    class ksw
    {
        public int[,] a(int[,] k)
        {
            int[,] kp = new int[k.GetLength(0), k.GetLength(1)];
            int x = k.GetLength(0);
            int y = k.GetLength(1);
            int[] k0 = new int[x * y];
            for (int i = 0; i < x; i++)
            {
                for (int j = 0; j < y; j++)
                {
                    k0[i * y + j] = k[i, j];
                }
            }
            int[] k1 = k0.Distinct().ToArray();
            for (int i = 0; i < k1.Length; i++)
            {
                for (int j = 0; j < k1.Length; j++)
                {
                    if (k1[j] > k1[i])
                    {
                        int p = k1[i];
                        k1[i] = k1[j];
                        k1[j] = p;
                    }
                }
            }
            int[] k2 = new int[k1.Length];
            for (int q = 0; q < k2.Length; q++)
            {
                k2[q] = 0;
            }
            for (int i = 0; i < x; i++)
            {
                for (int j = 0; j < y; j++)
                {
                    for (int q = 0; q < k1.Length; q++)
                    {
                        if (k1[q] == k[i, j])
                        {
                            k2[q]++;
                        }
                    }
                }
            }
            double[] k3 = new double[k2.Length];
            for (int q = 0; q < k3.Length; q++)
            {
                k3[q] = Convert.ToDouble(k2[q]) / (x * y);
            }
            int a = 0;
            double b = 0;
            for (int i = 0; i <k1.Length; i++)
            {
                double g1=0;
                double g2=0;
                double g3 = 0;
                for (int j = 0; j <= i; j++)
                {
                    g3 +=k3[j];
                }
                for (int j = 0; j <=i; j++)
                {
                    g1+=-(k3[j]* Math.Log(k3[j]));
                }
                for (int j = 0; j <k1.Length; j++)
                {
                    g2+=-(k3[j]* Math.Log(k3[j]));
                }
                double g = Math.Log(g3 * (1 - g3))+g1/g3+(g2-g1)/(1-g3);                
                if (g > b)
                {
                    a = k1[i];
                    b = g;
                }
            }
            for (int i = 0; i < x; i++)
            {
                for (int j = 0; j < y; j++)
                {
                    if (k[i, j] >= a)
                    {
                        kp[i, j] = 255;
                    }
                    else if (k[i, j] < a)
                    {
                        kp[i, j] = 0;
                    }
                }
            }
            return kp;
        }
    }
}
