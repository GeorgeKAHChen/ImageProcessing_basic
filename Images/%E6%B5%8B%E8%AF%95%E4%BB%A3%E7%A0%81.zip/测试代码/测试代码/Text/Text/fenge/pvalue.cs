﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Text
{
    class pvalue
    {
        public int[,] a(int[,] k)
        {
            int[,] kp = new int[k.GetLength(0), k.GetLength(1)];
            int x = k.GetLength(0);
            int y = k.GetLength(1);
            int b = 0;
            for (int i = 0; i < x; i++)
            {
                for (int j = 0; j < y; j++)
                {
                    b += k[i, j];
                }
            }
            int a = b / (x * y); int a0 = b / (x * y);
            do
            {
                int a1 = 0; int a2 = 0; int b1 = 0; int b2 = 0;
                for (int i = 0; i < x; i++)
                {
                    for (int j = 0; j < y; j++)
                    {
                        if (k[i, j] < a0)
                        {
                            b1 += k[i, j];
                            a1++;
                        }
                        else
                        {
                            b2 += k[i, j];
                            a2++;
                        }
                    }
                }
                a = a0;
                a0 = (b1 / a1 + b2 / a2) / 2;
            }
            while ((int)a != (int)a0);
            
            for (int i = 0; i < x; i++)
            {
                for (int j = 0; j < y; j++)
                {
                    if (k[i, j] >= a)
                    {
                        kp[i, j] = 255;
                    }
                    else if (k[i, j] < a)
                    {
                        kp[i, j] = 0;
                    }
                }
            }
            return kp;
        }
    }
}
